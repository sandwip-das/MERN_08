import express from "express";
const router = express.Router();
import * as FeaturesController from "../app/controllers/FeaturesController.js";


// Get Request:
router.get("/", (req, res) => {
    res.send("Hello World");
})

// Post Request:
router.post("/about", (req, res) => {
    res.send("I am post body");
})

// json web token in responsejson web token in response:
router.get("/task1/TokenEncode",FeaturesController.TokenEncode)
router.get("/task2/TokenDecode",FeaturesController.TokenDecode)



export default router;


