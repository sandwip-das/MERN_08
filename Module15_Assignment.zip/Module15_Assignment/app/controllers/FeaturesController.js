import {DecodeToken, EncodeToken} from "../utility/tokenUtility.js";
//import * as path from "node:path";

export const TokenEncode=async (req, res) => {
   let result= EncodeToken("sandwipdas@gmail.com",'pass#1234')
   res.json({token:result});
}

export const TokenDecode=async (req, res) => {
    let result= DecodeToken("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InNhbmR3aXBkYXNAZ21haWwuY29tIiwidXNlcl9pZCI6InBhc3MjMTIzNCIsImlhdCI6MTczNzA2MjA5NywiZXhwIjoxNzM5NjU0MDk3fQ.VipnjbSSjLzD0ztOgABL5S-dTKtjzphyezTgGJFHh8k")
    res.json({token:result});
}

